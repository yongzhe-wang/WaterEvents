#!/usr/bin/env bash
pkill -f chrome 2>/dev/null; sleep 1
cd /workspace/WaterEvents/backend || exit 1
export WATERCRAWL_NO_SHOT=1 WATERCRAWL_HTTP_FIRST=0 IR_WATERCRAWL_BROWSERS=2 PYTHONPATH=.
timeout 200 /root/venv/bin/python -u /workspace/tier3.py > /workspace/t3.log 2>&1
echo "RC=$?"
grep -E 'BROWSER|IMPERSONATE|GUARD|->|head:' /workspace/t3.log
