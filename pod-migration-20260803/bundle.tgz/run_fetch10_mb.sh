#!/bin/bash
cd /workspace/WaterEvents
export QWEN_BASE_URLS=http://127.0.0.1:8000/v1
export QWEN_SERVED_NAME=qwen-vl
export QWEN_API_KEY=sk-waterevents-0b1307fdf041607d7e55838c277320498bbee722867cad78
export QWEN_MAX_TOKENS=12000
export EVENT_VISION_TEXT_CHARS=24000
export EVENT_MAX_PAGES=40
export EVENT_USE_IMAGE=1
export FETCH_COMPANY_CONCURRENCY=10
export IR_WATERCRAWL_BROWSERS=8
export IR_WATERCRAWL_MAX_PAGES=24
exec /root/venv/bin/python -u fetch_10.py
