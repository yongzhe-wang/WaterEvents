#!/usr/bin/env bash
echo "=== playwright package version ==="
/root/venv/bin/python -c "import playwright; print(' ', playwright.__version__ if hasattr(playwright,'__version__') else 'n/a')" 2>&1
/root/venv/bin/pip show playwright 2>/dev/null | grep -E "^Version|^Name" | sed 's/^/  /'
echo "=== which chromium build playwright resolves to ==="
/root/venv/bin/python - <<'PY'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    print("  executable:", p.chromium.executable_path)
PY
echo "=== installed browser builds ==="
ls -1 /root/.cache/ms-playwright/ | sed 's/^/  /'
echo "=== does a bare launch survive 3 sequential contexts? ==="
/root/venv/bin/python - <<'PY'
from playwright.sync_api import sync_playwright
args = ["--disable-dev-shm-usage","--disable-gpu","--disable-software-rasterizer","--disable-extensions","--no-sandbox"]
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=args)
        for i in range(3):
            c = b.new_context(); pg = c.new_page()
            pg.goto("https://example.com", wait_until="domcontentloaded", timeout=20000)
            print(f"  ctx{i+1} ok chars={len(pg.inner_text('body'))}")
            c.close()
        b.close()
    print("  SURVIVED")
except Exception as e:
    print(f"  CRASH/ERR {type(e).__name__}: {str(e)[:160]}")
PY
