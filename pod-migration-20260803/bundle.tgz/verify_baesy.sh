#!/usr/bin/env bash
cd /workspace/WaterEvents/backend || exit 1
export WATERCRAWL_NO_SHOT=1 EVENT_USE_IMAGE=0 IR_WATERCRAWL_BROWSERS=2 PYTHONPATH=.
/root/venv/bin/python - <<'PY'
import re
from providers import watercrawl
U = "https://investors.baesystems.com/"
r = watercrawl.render_shot(U)
t = r.get("inline") or r.get("text") or ""
print("  RESULT method=%-12s text=%-6d links=%-4d" % (r.get("method"), len(t), len(r.get("links") or [])))
d = re.findall(r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+20\d{2}|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+20\d{2}', t)
print("  dates in result:", len(d), d[:5])
print("  head:", repr(t[:180]))
PY
