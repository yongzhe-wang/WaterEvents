#!/usr/bin/env bash
cd /workspace/WaterEvents/backend || exit 1
export WATERCRAWL_NO_SHOT=1 IR_WATERCRAWL_BROWSERS=2 PYTHONPATH=.
/root/venv/bin/python - <<'PY'
import importlib
from providers.watercrawl import runtime, detection, walls, config
R = importlib.import_module("providers.watercrawl.render")
from providers.watercrawl.engines import impersonate

U = "https://investors.baesystems.com/"
runtime.ensure_browser()
text, links, html, shot, inline = R._shot_via(U, config.SETTLE_FIXED_MS, None)
print(f"  tier1 chromium : text={len(text or '')} links={len(links or [])} inline={len(inline or '')}")
print(f"    body: {repr((text or '')[:100])}")
print(f"    looks_walled = {detection.looks_walled(text, links)}")
print(f"    looks_dead   = {walls.deadpage.looks_dead(text)!r}")
print(f"    is_challenge = {detection.is_challenge(text)}")
print(f"    dead_host    = {detection.dead_host(U)}")
try:
    i_text, i_links, i_html = impersonate.fetch(U)
except Exception as e:
    i_text, i_links, i_html = "", [], ""
    print("    impersonate ERR", type(e).__name__)
print(f"  tier2 impersonate: text={len(i_text or '')} links={len(i_links or [])}")
print(f"    body: {repr((i_text or '')[:100])}")
print(f"    is_challenge = {detection.is_challenge(i_text)}  -> tier2 {'RETURNS' if (i_text and not detection.is_challenge(i_text)) else 'falls through'}")
PY
