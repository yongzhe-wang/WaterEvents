#!/usr/bin/env bash
echo "=== bare playwright on CECO — does the PAGE crash chromium? ==="
/root/venv/bin/python - <<'PY'
from playwright.sync_api import sync_playwright
URL = "https://investors.cecoenviro.com/news-events/events"
args = ["--disable-dev-shm-usage","--disable-gpu","--disable-software-rasterizer","--disable-extensions","--no-sandbox"]
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=args)
        c = b.new_context(user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
        pg = c.new_page()
        r = pg.goto(URL, wait_until="domcontentloaded", timeout=30000)
        print("  http_status:", r.status if r else None)
        print("  final_url  :", pg.url)
        txt = pg.inner_text("body")
        links = pg.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
        print(f"  text={len(txt)} links={len(links)}")
        print("  head:", repr(txt[:220]))
        c.close(); b.close()
    print("  NO CRASH")
except Exception as e:
    print(f"  ERR {type(e).__name__}: {str(e)[:200]}")
PY
