#!/bin/bash
pkill -9 -f vlmtest
sleep 2
