#!/bin/bash
# kill lingering stress client python (NOT the vllm server), clear, run the 4096/C24 stress FOREGROUND
ps -eo pid,cmd | grep python | grep -E "stress_all|run_stress" | grep -v clean_and_run | grep -v grep | awk "{print \$1}" | xargs -r kill -9
sleep 1
rm -f /workspace/WaterEvents/tests/stress_txt/req_*.txt /workspace/WaterEvents/tests/stress_txt/summary.json
cd /workspace/WaterEvents && exec env HF_HOME=/workspace/hf /root/venv/bin/python /workspace/stress_all.py
