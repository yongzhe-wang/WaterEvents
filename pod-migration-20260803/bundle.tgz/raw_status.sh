#!/usr/bin/env bash
cd /workspace/WaterEvents/backend || exit 1
export PYTHONPATH=.
/root/venv/bin/python - <<'PY'
from curl_cffi import requests as creq
UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36", "Accept": "*/*"}
for u in ["https://investors.cecoenviro.com/news-events/events",
          "https://investors.amgen.com/news-releases",
          "https://www.shimano.com/en/ir/calendar.html"]:
    try:
        r = creq.get(u, impersonate="chrome", timeout=20, headers=UA)
        body = (r.text or "")[:110].replace("\n", " ")
        print(f"  {r.status_code}  len={len(r.text or ''):>7}  {u}")
        if r.status_code != 200:
            print(f"        {body!r}")
    except Exception as e:
        print(f"  ERR {type(e).__name__}: {str(e)[:90]}  {u}")
PY
