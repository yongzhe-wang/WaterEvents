#!/usr/bin/env bash
cd /workspace/WaterEvents/backend || exit 1
export PYTHONPATH=. WATERCRAWL_NO_SHOT=1
/root/venv/bin/python - <<'PY'
from providers.watercrawl import politeness as P
from providers.watercrawl.engines import impersonate
U = "https://investors.cecoenviro.com/news-events/events"
print("  politeness.url_allowed :", P.url_allowed(U))
print("  robots allowed         :", P.allowed(U))
print("  host_is_public         :", P.host_is_public("investors.cecoenviro.com"))
try:
    it, il, ih = impersonate.fetch(U)
    print("  impersonate.fetch      : text=%d links=%d html=%d" % (len(it or ""), len(il or []), len(ih or "")))
except Exception as e:
    print("  impersonate.fetch ERR  :", type(e).__name__, str(e)[:120])
PY
