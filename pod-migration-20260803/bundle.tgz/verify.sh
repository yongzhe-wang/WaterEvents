#!/usr/bin/env bash
cd /workspace/WaterEvents/backend || exit 1
export WATERCRAWL_NO_SHOT=1 EVENT_USE_IMAGE=0 IR_WATERCRAWL_BROWSERS=2 PYTHONPATH=.
/root/venv/bin/python -c "import providers.watercrawl.render" 2>&1 | tail -2
/root/venv/bin/python - <<'PY'
from providers import watercrawl
for u in ["https://investors.cecoenviro.com/news-events/events"]:
    r = watercrawl.render_shot(u)
    t = r.get("inline") or r.get("text") or ""
    print("  RESULT method=%-12s text=%-6d links=%-4d" % (r.get("method"), len(t), len(r.get("links") or [])))
    import re
    d = re.findall(r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+20\d{2}', t)
    print("  dates found:", len(d), d[:4])
PY
