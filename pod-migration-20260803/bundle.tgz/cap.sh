echo "=== pod CPU / RAM ==="
echo "  cores: $(nproc)"
free -g | awk '/Mem:/{print "  ram: " $2 "G total, " $7 "G available"}'
echo "  load:$(uptime | sed 's/.*load average://')"
echo "=== other tests running? (you asked for sequential) ==="
pgrep -af 'python.*(diag|probe|collect|dataset)' | grep -v pgrep | sed 's/^/  /' || echo "  none"
echo "=== single browser render timing ==="
cd /workspace/WaterEvents/backend
export PYTHONPATH=. WATERCRAWL_NO_SHOT=1
/root/venv/bin/python - <<'PY' 2>&1 | grep -vE '^\[|Warning'
import time
from providers import watercrawl
for u in ["https://investors.boeing.com/investors/events-and-presentations/default.aspx",
          "https://investors.amgen.com/news-releases"]:
    t = time.time(); r = watercrawl.render_shot(u); dt = time.time() - t
    txt = r.get("inline") or r.get("text") or ""
    print(f"  {dt:6.1f}s  method={r.get('method'):<12} text={len(txt):>7}  {u[:52]}")
PY
