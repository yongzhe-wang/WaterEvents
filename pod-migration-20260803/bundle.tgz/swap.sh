#!/bin/bash
# one-shot: stop old supervisor + server, start the NEW flock-singleton supervisor. Its own cmdline is "bash
# /workspace/swap.sh" so the pkills below do not self-match.
pkill -f "supervise_vl" 2>/dev/null
sleep 2
pkill -f "vllm.entrypoints" 2>/dev/null
sleep 3
rm -f /workspace/.supervisor.lock
setsid nohup /workspace/supervise_vl.sh >> /workspace/supervisor.log 2>&1 < /dev/null &
echo "SWAP_DONE new supervisor pid=$!"
