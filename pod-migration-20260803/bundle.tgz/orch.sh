#!/bin/bash
# kill ONLY python vlmtest/run.py procs (exe-filter → never kills a bash/ssh that merely mentions vlmtest in argv)
for p in $(pgrep -f "vlmtest/run.py"); do
  exe=$(readlink /proc/$p/exe 2>/dev/null)
  case "$exe" in *python*) kill -9 "$p";; esac
done
sleep 3
rm -f /workspace/vlmtest/txt/req_*.txt /workspace/vlmtest/txt/summary.json
cd /workspace/WaterEvents
HF_HOME=/workspace/hf nohup /root/venv/bin/python /workspace/vlmtest/run.py > /workspace/vlmtest/run.log 2>&1 &
echo "launched pid=$!"
