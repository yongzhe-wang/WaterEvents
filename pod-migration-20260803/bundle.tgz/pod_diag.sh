#!/usr/bin/env bash
# Pod environment diagnosis — everything that must be true before a wall-related conclusion is trustworthy.
echo "=== /dev/shm (chromium crash suspect #1) ==="
df -h /dev/shm | tail -1
echo "=== memory ==="
free -g | head -2
echo "=== cpu ==="
nproc
echo "=== chromium flags in code ==="
grep -n "disable-dev-shm-usage" /workspace/WaterEvents/backend/providers/watercrawl/runtime.py | head -2
echo "=== existing pod env files ==="
ls -1 /workspace/*.env 2>/dev/null
echo "=== WEBSHARE present on pod? ==="
grep -l WEBSHARE /workspace/*.env 2>/dev/null || echo "  none"
echo "=== chromium binary ==="
ls -1 /root/.cache/ms-playwright/ 2>/dev/null | head -3
