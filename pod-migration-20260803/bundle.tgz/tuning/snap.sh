#!/bin/bash
# 每小时快照 vLLM 关键指标,用于评估 2026-08-03 的调参效果(max-num-seqs 64→32, max-model-len 32768→12288)
# 删除方法: crontab -e 删掉这一行,或 rm /workspace/tuning/snap.sh
curl -s -m 10 http://127.0.0.1:8000/metrics 2>/dev/null | \
  grep -E "^vllm:(num_preemptions_total|num_requests_(running|waiting)\{|e2e_request_latency_seconds_(sum|count)|request_queue_time_seconds_(sum|count)|kv_cache_usage_perc)" | \
  sed "s|^|$(date -u +%FT%TZ) |" >> /workspace/tuning/hourly.tsv
